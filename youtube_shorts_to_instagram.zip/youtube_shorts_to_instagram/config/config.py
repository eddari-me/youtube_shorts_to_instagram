# config/config.py

YOUTUBE_API_KEY = 'your_youtube_api_key_here'
INSTAGRAM_API_KEY = 'your_instagram_api_key_here'
INSTAGRAM_USERNAME = 'your_instagram_username_here'
INSTAGRAM_PASSWORD = 'your_instagram_password_here'
